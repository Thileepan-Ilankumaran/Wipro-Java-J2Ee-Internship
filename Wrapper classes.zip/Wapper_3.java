import java.util.Scanner;

public class Wapper_3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number: ");
		int number = sc.nextInt();
		String binaryNum = Integer.toBinaryString(number);
		int length = binaryNum.length();
		if(length < 8 ) {
			for(int i = length; i < 8; ++i ) {
				System.out.print("0");
			}
		}
		System.out.print(binaryNum);
		sc.close();
	}
}