package com.mile1.exception;

public class NullMarksArrayException extends Exception {
    @Override
    public String toString() {
        return "NullMarksArrayException occurred";
    }
}
