select last_name, salary from employees 
where salary > 12000;