package Arrays;

public class Assignments12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] a= {1,2,3};
		    int[] b= {4,5,6};
		    int[] c= {};
		    System.out.print(a[1]+" ");
		    System.out.print(b[1]);
		    
	}

}
