package Arrays;

import java.util.Scanner;

public class Assignment09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt(),i,j;
		int a[]=new int[n];
		int temp;
		for(i=0;i<n;i++) {
			a[i]=sc.nextInt();
		}
		for(i=0;i<n;i++) {  
			for(j=i+1;j<n;j++) {
				if(a[i]==10) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		for(i=0;i<n;i++) {
			if(a[i]==10)
				a[i]-=10;
			System.out.print(a[i]+" ");
		}
	}

}
