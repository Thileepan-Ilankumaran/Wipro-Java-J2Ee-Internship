package Arrays;

import java.util.Scanner;

public class Assignments11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	    String data = sc.nextLine();
	    String[] num = data.split(",");

	    int[] numbers = new int[num.length];

	    for(int i = 0; i< num.length;i++){
	      numbers[i] = Integer.parseInt(num[i]);
	    }

	    //implementation
	    int f = 0;
	    for(int i = 0; i< numbers.length;i++){
	      if(numbers[i] != 1 && numbers[i] != 4){
	        f = 1;
	      }
	    }
	    if(f == 0){
	      System.out.println("true");
	    }else{
	      System.out.println("false");
	    }
	}

}
