package Arrays;

import java.util.Arrays;

public class Assignments06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int[] array = {19, 17, 30, 18, 6};
		
		Arrays.sort(array);												
		
		/*for(int i = 0; i < array.length-1; i++) {					
			for(int j = 0; j < array.length-1; j++) {
				if(array[j] > array[j+1]) {
					int temp = array[j+1];
					array[j+1] = array[j];
					array[j] = temp;
				}
			}
		}
       */
		
		System.out.print("Sorted Array : ");
		for(int element : array) {
			System.out.print(element + " ");
		}
	}

}
