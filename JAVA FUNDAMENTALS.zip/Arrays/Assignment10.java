package Arrays;

import java.util.Scanner;

public class Assignment10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Scanner sc=new Scanner(System.in);
			int n=sc.nextInt();
			int a[]=new int[n];
			for(int i=0;i<n;i++) {
				a[i]=sc.nextInt();
			}
			int i=0;
			while(i<n && a[i]%2==0)
				i++;
			for(int j=i+1;j<n;j++) {
				if(a[j]%2==0) {
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
					i++;
				}
			}
			System.out.print(a[0]);
			for(i=1;i<n;i++) {
				System.out.print(", "+a[i]);
			}
	}

}
