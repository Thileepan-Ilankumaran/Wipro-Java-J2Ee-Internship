package flowcontrolstatement;

public class Assignment04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char var1 = 's';
		char var2 = 'e';
		
		if (var1>var2)
	   System.out.println(var2+" , "+var1);
   else
	   System.out.println(var1+" , "+var2);
	}

}
