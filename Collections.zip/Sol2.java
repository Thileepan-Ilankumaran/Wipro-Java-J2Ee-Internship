package  com.collections;
import  java.util.HashMap;
class Sol2
{
     HashMap<String,String> mapobj=new HashMap<>();
    public HashMap<String, String> saveCountryCapital(String  countryName, String capital)
    {
        mapobj.put(countryName, capital);
        return mapobj;
        
    }

    public String getCapital(String  countryName)
    {
       return  mapobj.containsKey(countryName) ?(mapobj.get(countryName)):(("No Country Found"));
    }

    public  static  void  main(String args[])
    {

        Sol2 obj=new Sol2();
        System.out.println(obj.saveCountryCapital("India","New Delhi"));
        System.out.println(obj.saveCountryCapital("Pakistan","Islamabad"));
        System.out.println(obj.saveCountryCapital("Pakistan","India"));
        System.out.println(obj.getCapital("Russia"));
    }
}
