package com.collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Sol4
{
    HashMap<String,String> mapobj=new HashMap<>();
    public HashMap<String, String> saveCountryCapital(String  countryName, String capital)
    {
        mapobj.put(countryName, capital);
        return mapobj;

    }

    public HashMap<String,String > swapHashMap()
    {
        HashMap<String,String> mapobj1=new HashMap<>();
        Set entrymap=mapobj.entrySet();
        Iterator it=entrymap.iterator();
        while (it.hasNext())
        {
         Map.Entry<String,String> me= (Map.Entry<String, String>) it.next();
          mapobj1.put(me.getValue(),me.getKey());

        }
        return mapobj1;
    }

    public  static  void main(String args[])
    {

        Sol4 obj=new Sol4();
        System.out.println(obj.saveCountryCapital("India","New Delhi"));
        System.out.println(obj.saveCountryCapital("Russia","Moscow"));
        System.out.println(obj.saveCountryCapital("Israel","Istanbul"));
        System.out.println(obj.swapHashMap());
    }
}
