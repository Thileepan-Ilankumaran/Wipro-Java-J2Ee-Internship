package com.collections;
import java.util.HashMap;

public class Sol3
{
    HashMap<String,String> mapobj=new HashMap<>();
    public HashMap<String, String> saveCountryCapital(String  countryName, String capital)
    {
        mapobj.put(countryName, capital);
        return mapobj;

    }

    public String getCountry(String capital )
    {
        return mapobj.containsKey(capital) ?(mapobj.get(capital)): "No Capital Found";
    }

    public  static  void main (String args[])
    {
        Sol3 obj=new Sol3();
        System.out.println(obj.saveCountryCapital("India","New Delhi"));
        System.out.println(obj.saveCountryCapital("Russia","Moscow"));
        System.out.println(obj.saveCountryCapital("Israel","Istanbul"));
        System.out.println(obj.getCountry("Israel"));
        System.out.println(obj.getCountry("Bangladesh"));
    }


}
