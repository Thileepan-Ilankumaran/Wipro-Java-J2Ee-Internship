package com.collections;
import java.util.HashMap;

public class Sol1

{
    HashMap<String ,String> mapobj=new HashMap<>();

    public HashMap<String, String> saveCountryCapital(String countryName, String capital)
    {

        mapobj.put(countryName,capital);
        return  mapobj;
    }

    public static  void main (String args[])
    {

        Sol1 ob=new Sol1();
       System.out.println(ob.saveCountryCapital("India","New Delhi"));
       System.out.println(ob.saveCountryCapital("Japan","Tokyo"));
       System.out.println(ob.saveCountryCapital("India","New Delhi"));
       System.out.println(ob.saveCountryCapital("India","Banaras"));

    }
}

